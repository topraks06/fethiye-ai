export interface Place {
    id: number;
    title: string;
    description: string;
    image: string;
}

export interface Hotel {
    id: number;
    name: string;
    price: string;
    rating: number;
    image: string;
}

export const popularPlaces: Place[] = [
    {
        id: 1,
        title: 'Ölüdeniz',
        description: 'Dünyaca ünlü turkuaz suları ve eşsiz kumsalıyla bir yeryüzü cenneti.',
        image: '/place-thumbnail.jpg',
    },
    {
        id: 2,
        title: 'Saklıkent Kanyonu',
        description: 'Doğanın gücünü hissedebileceğiniz, serin sularıyla büyüleyen kanyon.',
        image: '/place-thumbnail.jpg',
    },
    {
        id: 3,
        title: 'Kayaköy',
        description: 'Tarihin izlerini taşıyan, hüzünlü ve büyüleyici hayalet köy.',
        image: '/place-thumbnail.jpg',
    },
    {
        id: 4,
        title: 'Kelebekler Vadisi',
        description: 'Sadece denizden ulaşılabilen, doğa harikası bir vadi.',
        image: '/place-thumbnail.jpg',
    },
    {
        id: 5,
        title: 'Çalış Plajı',
        description: 'Fethiye\'nin en güzel gün batımını izleyebileceğiniz uzun sahil şeridi.',
        image: '/place-thumbnail.jpg',
    },
    {
        id: 6,
        title: 'Amintas Kaya Mezarları',
        description: 'Şehri tepeden izleyen, Likya döneminden kalma büyüleyici kaya mezarları.',
        image: '/place-thumbnail.jpg',
    },
];

export const hotels: Hotel[] = [
    {
        id: 1,
        name: 'Yacht Classic Hotel',
        price: '₺8.500 / gece',
        rating: 4.9,
        image: '/hotel-thumbnail.jpg',
    },
    {
        id: 2,
        name: 'Hillside Beach Club',
        price: '₺15.000 / gece',
        rating: 5.0,
        image: '/hotel-thumbnail.jpg',
    },
    {
        id: 3,
        name: 'Liberty Fabay',
        price: '₺12.000 / gece',
        rating: 4.8,
        image: '/hotel-thumbnail.jpg',
    },
    {
        id: 4,
        name: 'Sundia Exclusive',
        price: '₺7.500 / gece',
        rating: 4.7,
        image: '/hotel-thumbnail.jpg',
    },
];

export const tours: Tour[] = [
    {
        id: 1,
        title: '12 Adalar Tekne Turu',
        duration: 'Tam Gün',
        price: '₺1.500',
        image: '/oludeniz-hero.jpg',
        category: 'Tekne',
    },
    {
        id: 2,
        title: 'Babadağ Yamaç Paraşütü',
        duration: '2 Saat',
        price: '₺3.500',
        image: '/place-thumbnail.jpg',
        category: 'Macera',
    },
    {
        id: 3,
        title: 'Saklıkent Jeep Safari',
        duration: 'Tam Gün',
        price: '₺1.200',
        image: '/place-thumbnail.jpg',
        category: 'Macera',
    },
    {
        id: 4,
        title: 'Gün Batımı Özel Tekne',
        duration: '4 Saat',
        price: '₺10.000',
        image: '/oludeniz-hero.jpg',
        category: 'Özel',
    },
];

export const transfers: Transfer[] = [
    {
        id: 1,
        title: 'Dalaman Havalimanı - Fethiye',
        type: 'VIP Mercedes Vito',
        price: '₺2.500',
        image: '/place-thumbnail.jpg',
    },
    {
        id: 2,
        title: 'Dalaman Havalimanı - Ölüdeniz',
        type: 'VIP Mercedes Vito',
        price: '₺2.800',
        image: '/place-thumbnail.jpg',
    },
    {
        id: 3,
        title: 'Günlük Şoförlü Araç',
        type: 'Mercedes S-Class',
        price: '₺15.000',
        image: '/place-thumbnail.jpg',
    },
];

export const realEstate: RealEstate[] = [
    {
        id: 1,
        title: 'Ölüdeniz Manzaralı Lüks Villa',
        type: 'Satılık',
        price: '€750.000',
        location: 'Ovacık',
        features: ['4 Oda', 'Özel Havuz', '500m2'],
        image: '/hotel-thumbnail.jpg',
    },
    {
        id: 2,
        title: 'Denize Sıfır Yazlık',
        type: 'Kiralık',
        price: '₺120.000 / Ay',
        location: 'Çalış',
        features: ['3 Oda', 'Site İçi', 'Mobilyalı'],
        image: '/hotel-thumbnail.jpg',
    },
    {
        id: 3,
        title: 'Modern Taş Ev',
        type: 'Satılık',
        price: '€450.000',
        location: 'Kayaköy',
        features: ['2 Oda', 'Bahçeli', 'Tarihi Doku'],
        image: '/hotel-thumbnail.jpg',
    },
];

export const localExperts: LocalExpert[] = [
    {
        id: 1,
        name: 'Ahmet Yılmaz',
        profession: 'Elektrik Ustası',
        rating: 4.8,
        contact: '+90 555 123 4567',
        image: '/place-thumbnail.jpg',
    },
    {
        id: 2,
        name: 'Ayşe Demir',
        profession: 'Özel Tur Rehberi',
        rating: 5.0,
        contact: '+90 555 987 6543',
        image: '/place-thumbnail.jpg',
    },
    {
        id: 3,
        name: 'Mehmet Kaya',
        profession: 'Tesisatçı',
        rating: 4.6,
        contact: '+90 555 456 7890',
        image: '/place-thumbnail.jpg',
    },
];
