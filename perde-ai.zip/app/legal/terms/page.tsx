'use client';

import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';

export default function TermsPage() {
    return (
        <div className="min-h-screen bg-off-white">
            <Navbar />
            <div className="max-w-4xl mx-auto px-6 py-32">
                <h1 className="text-4xl font-bold mb-8 text-deep-blue">Kullanım Şartları</h1>
                <div className="prose prose-lg">
                    <p>Son güncelleme: 24 Kasım 2025</p>
                    <p>Fethiye.ai platformunu kullanarak aşağıdaki şartları kabul etmiş sayılırsınız.</p>
                    <h3>1. Hizmet Kullanımı</h3>
                    <p>Platform üzerindeki içerikler bilgilendirme amaçlıdır. Kesin rezervasyon bilgisi için ilgili işletme ile görüşünüz.</p>
                    <h3>2. Sorumluluk Reddi</h3>
                    <p>Fethiye.ai, listelenen hizmetlerdeki fiyat veya müsaitlik değişikliklerinden sorumlu tutulamaz.</p>
                    <h3>3. Değişiklikler</h3>
                    <p>Bu şartlar önceden haber verilmeksizin değiştirilebilir.</p>
                </div>
            </div>
            <Footer />
        </div>
    );
}
