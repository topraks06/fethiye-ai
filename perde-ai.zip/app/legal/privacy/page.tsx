'use client';

import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';

export default function PrivacyPage() {
    return (
        <div className="min-h-screen bg-off-white">
            <Navbar />
            <div className="max-w-4xl mx-auto px-6 py-32">
                <h1 className="text-4xl font-bold mb-8 text-deep-blue">Gizlilik Politikası</h1>
                <div className="prose prose-lg">
                    <p>Son güncelleme: 24 Kasım 2025</p>
                    <p>Fethiye.ai olarak gizliliğinize önem veriyoruz. Bu politika, kişisel verilerinizin nasıl toplandığını ve kullanıldığını açıklar.</p>
                    <h3>1. Toplanan Veriler</h3>
                    <p>Sitemizi ziyaret ettiğinizde IP adresi, tarayıcı bilgileri gibi standart log kayıtları tutulmaktadır.</p>
                    <h3>2. Çerezler</h3>
                    <p>Kullanıcı deneyimini geliştirmek için çerezler (cookies) kullanılmaktadır.</p>
                    <h3>3. İletişim</h3>
                    <p>Sorularınız için info@fethiye.ai adresinden bize ulaşabilirsiniz.</p>
                </div>
            </div>
            <Footer />
        </div>
    );
}
