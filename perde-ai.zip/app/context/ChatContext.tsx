'use client';

import React, { createContext, useContext, useState, ReactNode } from 'react';

interface ChatContextType {
    isOpen: boolean;
    toggleChat: () => void;
    openChatWithQuery: (query: string) => void;
    initialQuery: string;
    clearInitialQuery: () => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export function ChatProvider({ children }: { children: ReactNode }) {
    const [isOpen, setIsOpen] = useState(false);
    const [initialQuery, setInitialQuery] = useState('');

    const toggleChat = () => setIsOpen((prev) => !prev);

    const openChatWithQuery = (query: string) => {
        setInitialQuery(query);
        setIsOpen(true);
    };

    const clearInitialQuery = () => setInitialQuery('');

    return (
        <ChatContext.Provider
            value={{
                isOpen,
                toggleChat,
                openChatWithQuery,
                initialQuery,
                clearInitialQuery,
            }}
        >
            {children}
        </ChatContext.Provider>
    );
}

export function useChat() {
    const context = useContext(ChatContext);
    if (context === undefined) {
        throw new Error('useChat must be used within a ChatProvider');
    }
    return context;
}
