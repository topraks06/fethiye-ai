'use client';

import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import ChatWidget from '../components/ChatWidget';
import ServiceCard from '../components/ServiceCard';
import { transfers } from '@/lib/data';
import { useChat } from '@/app/context/ChatContext';

export default function TransfersPage() {
    const { openChatWithQuery } = useChat();

    return (
        <div className="min-h-screen bg-off-white">
            <Navbar />

            {/* Hero Section */}
            <div className="relative h-[50vh] flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 z-0">
                    <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-deep-blue/40 z-10" />
                    <img
                        src="/place-thumbnail.jpg"
                        alt="VIP Transfer"
                        className="w-full h-full object-cover"
                    />
                </div>
                <div className="relative z-20 text-center text-white px-4">
                    <h1 className="text-5xl md:text-7xl font-black mb-4 drop-shadow-lg">
                        Konforlu <span className="text-turquoise">Yolculuk</span>
                    </h1>
                    <p className="text-xl md:text-2xl max-w-2xl mx-auto font-light">
                        VIP araçlar ve özel şoförler ile tatiliniz kapınızda başlasın.
                    </p>
                </div>
            </div>

            {/* Content */}
            <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {transfers.map((transfer) => (
                        <ServiceCard
                            key={transfer.id}
                            title={transfer.title}
                            subtitle={transfer.type}
                            price={transfer.price}
                            image={transfer.image}
                            badges={['VIP', '7/24']}
                            actionLabel="Transfer Ayarla"
                            onAction={() => openChatWithQuery(`${transfer.title} için transfer ayarlamak istiyorum.`)}
                        />
                    ))}
                </div>
            </div>

            <Footer />
            <ChatWidget />
        </div>
    );
}
