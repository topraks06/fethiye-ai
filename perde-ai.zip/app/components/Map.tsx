'use client';

import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { Icon } from 'leaflet';
import { useEffect, useState } from 'react';

// Fix for default marker icon
const customIcon = new Icon({
    iconUrl: 'https://cdn-icons-png.flaticon.com/512/684/684908.png',
    iconSize: [38, 38]
});

interface MapProps {
    locations: Array<{
        id: number;
        title: string;
        lat: number;
        lng: number;
        type: string;
    }>;
}

export default function Map({ locations }: MapProps) {
    const [isMounted, setIsMounted] = useState(false);

    useEffect(() => {
        setIsMounted(true);
    }, []);

    if (!isMounted) return <div className="h-full w-full bg-gray-100 animate-pulse rounded-xl" />;

    return (
        <MapContainer
            center={[36.6213, 29.1164]}
            zoom={13}
            className="h-full w-full rounded-xl z-0"
        >
            <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {locations.map((loc) => (
                <Marker key={loc.id} position={[loc.lat, loc.lng]} icon={customIcon}>
                    <Popup>
                        <div className="p-2">
                            <h3 className="font-bold text-deep-blue">{loc.title}</h3>
                            <span className="text-xs bg-turquoise/20 text-deep-blue px-2 py-1 rounded-full mt-1 inline-block">
                                {loc.type}
                            </span>
                        </div>
                    </Popup>
                </Marker>
            ))}
        </MapContainer>
    );
}
