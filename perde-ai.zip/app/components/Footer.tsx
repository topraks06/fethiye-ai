'use client';

import Link from 'next/link';

export default function Footer() {
    return (
        <footer className="relative bg-deep-blue text-white overflow-hidden mt-20">
            {/* Glassmorphism Background Pattern */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 opacity-10">
                <div className="absolute -top-20 -left-20 w-96 h-96 bg-turquoise rounded-full blur-3xl"></div>
                <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-purple-500 rounded-full blur-3xl"></div>
            </div>

            <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16 relative z-10">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">

                    {/* Column 1: Brand & Description */}
                    <div className="space-y-6">
                        <Link href="/" className="inline-block group">
                            <span className="text-3xl font-black tracking-tight">
                                <span className="text-turquoise">Fethiye</span>
                                <span className="text-white">.ai</span>
                            </span>
                        </Link>
                        <p className="text-white/70 leading-relaxed font-light">
                            Fethiye'nin en özel köşelerini, lüks konaklama seçeneklerini ve unutulmaz deneyimlerini yapay zeka destekli asistanınızla keşfedin.
                        </p>
                        <div className="flex space-x-4">
                            {/* Social Icons */}
                            {['instagram', 'twitter', 'facebook'].map((social) => (
                                <a key={social} href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-turquoise hover:text-deep-blue transition-all duration-300">
                                    <span className="sr-only">{social}</span>
                                    <div className="w-5 h-5 bg-current rounded-sm opacity-50"></div>
                                </a>
                            ))}
                        </div>
                    </div>

                    {/* Column 2: Hizmetler */}
                    <div>
                        <h3 className="text-xl font-bold mb-6 text-turquoise font-serif">Hizmetlerimiz</h3>
                        <ul className="space-y-4">
                            {[
                                { name: 'Tekne Turları & Aktiviteler', href: '/tours' },
                                { name: 'VIP Transfer & Araç', href: '/transfers' },
                                { name: 'Lüks Villa & Emlak', href: '/real-estate' },
                                { name: 'Yerel Uzmanlar', href: '/services' },
                                { name: 'Oteller', href: '/hotels' }
                            ].map((item) => (
                                <li key={item.name}>
                                    <Link href={item.href} className="text-white/70 hover:text-white hover:translate-x-2 transition-all duration-300 inline-block flex items-center gap-2">
                                        <span className="w-1.5 h-1.5 bg-turquoise rounded-full"></span>
                                        {item.name}
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    </div>

                    {/* Column 3: Kurumsal */}
                    <div>
                        <h3 className="text-xl font-bold mb-6 text-turquoise font-serif">Kurumsal</h3>
                        <ul className="space-y-4">
                            {[
                                { name: 'Hakkımızda', href: '#' },
                                { name: 'İletişim', href: '#' },
                                { name: 'Gizlilik Politikası', href: '/legal/privacy' },
                                { name: 'Kullanım Şartları', href: '/legal/terms' },
                            ].map((item) => (
                                <li key={item.name}>
                                    <Link href={item.href} className="text-white/70 hover:text-white transition-colors duration-300">
                                        {item.name}
                                    </Link>
                                </li>
                            ))}
                        </ul>
                        <div className="mt-8">
                            <p className="text-sm text-white/50">
                                &copy; {new Date().getFullYear()} Fethiye.ai<br />Tüm hakları saklıdır.
                            </p>
                        </div>
                    </div>

                    {/* Column 4: Sponsorlar */}
                    <div>
                        <h3 className="text-xl font-bold mb-6 text-turquoise font-serif">Sponsorlar</h3>
                        <div className="space-y-4">
                            {/* Main Sponsor */}
                            <div className="bg-white/5 border border-white/10 rounded-xl p-4 text-center hover:bg-white/10 transition-colors cursor-pointer group">
                                <div className="h-12 flex items-center justify-center text-white/80 font-bold tracking-widest group-hover:text-turquoise transition-colors">
                                    ANA SPONSOR
                                </div>
                                <p className="text-xs text-white/40 mt-1">Reklam Alanı</p>
                            </div>

                            {/* Sub Sponsors */}
                            <div className="grid grid-cols-2 gap-4">
                                <div className="bg-white/5 border border-white/10 rounded-xl p-3 text-center hover:bg-white/10 transition-colors cursor-pointer">
                                    <div className="h-8 flex items-center justify-center text-white/60 text-sm font-bold">
                                        SPONSOR
                                    </div>
                                </div>
                                <div className="bg-white/5 border border-white/10 rounded-xl p-3 text-center hover:bg-white/10 transition-colors cursor-pointer">
                                    <div className="h-8 flex items-center justify-center text-white/60 text-sm font-bold">
                                        SPONSOR
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </footer>
    );
}
