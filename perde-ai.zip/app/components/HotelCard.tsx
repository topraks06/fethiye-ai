import Image from 'next/image';
import { Hotel } from '@/lib/data';

export default function HotelCard({ hotel }: { hotel: Hotel }) {
    return (
        <div className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border border-gray-100">
            <div className="relative h-64 w-full overflow-hidden">
                <Image
                    src={hotel.image}
                    alt={hotel.name}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-bold text-deep-blue shadow-sm">
                    ★ {hotel.rating}
                </div>
            </div>

            <div className="p-6">
                <h3 className="text-xl font-bold text-deep-blue mb-2">{hotel.name}</h3>
                <div className="flex items-center justify-between mt-4">
                    <span className="text-turquoise font-bold text-lg">{hotel.price}</span>
                    <button className="text-sm font-semibold text-gray-500 hover:text-deep-blue transition-colors">
                        Detaylar →
                    </button>
                </div>
            </div>
        </div>
    );
}
