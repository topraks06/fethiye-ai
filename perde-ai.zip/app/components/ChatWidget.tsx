'use client';

import { useState, useEffect, useRef } from 'react';
import { useChat } from '@/app/context/ChatContext';
import { usePathname } from 'next/navigation';

export default function ChatWidget() {
    const { isOpen, toggleChat, initialQuery, clearInitialQuery } = useChat();
    const pathname = usePathname();
    const [messages, setMessages] = useState<{ role: string; content: string }[]>([]);
    const [inputValue, setInputValue] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    // Initialize chat with context-aware message
    useEffect(() => {
        let greeting = 'Merhaba! Ben Fethiye Asistanı. Size nasıl yardımcı olabilirim?';

        if (pathname === '/tours') {
            greeting = 'Merhaba! Fethiye\'nin eşsiz koylarını ve macera turlarını keşfetmek ister misiniz? Size en uygun turu bulabilirim.';
        } else if (pathname === '/transfers') {
            greeting = 'Merhaba! Havalimanı transferi veya araç kiralama konusunda yardıma mı ihtiyacınız var?';
        } else if (pathname === '/real-estate') {
            greeting = 'Merhaba! Fethiye\'de hayalinizdeki evi veya yatırım fırsatını bulmanıza yardımcı olabilirim.';
        } else if (pathname === '/services') {
            greeting = 'Merhaba! Elektrikçi, tesisatçı veya özel rehber mi arıyorsunuz? Size en iyi yerel uzmanları önerebilirim.';
        }

        setMessages([{ role: 'assistant', content: greeting }]);
    }, [pathname]);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages, isTyping, isOpen]);

    useEffect(() => {
        if (initialQuery && isOpen) {
            handleSendMessage(undefined, initialQuery);
            clearInitialQuery();
        }
    }, [initialQuery, isOpen]);

    const handleSendMessage = (e?: React.FormEvent, overrideMsg?: string) => {
        if (e) e.preventDefault();
        const msgText = overrideMsg || inputValue;
        if (!msgText.trim()) return;

        setMessages((prev) => [...prev, { role: 'user', content: msgText }]);
        setInputValue('');
        setIsTyping(true);

        // Mock response with typing delay
        setTimeout(() => {
            setIsTyping(false);
            let response = `"${msgText}" hakkında harika önerilerim var! Size en uygun seçenekleri listeliyorum...`;

            // Simple context-aware mock responses
            if (pathname === '/tours') {
                response = `Harika bir seçim! "${msgText}" için en popüler turlarımızı kontrol ediyorum. Tarih tercihiniz var mı?`;
            } else if (pathname === '/transfers') {
                response = `Transfer talebinizi aldım. "${msgText}" için müsait araçlarımızı listeliyorum. Kaç kişi olacaksınız?`;
            }

            setMessages((prev) => [
                ...prev,
                { role: 'assistant', content: response },
            ]);
        }, 2000);
    };

    return (
        <>
            {/* Floating Action Button */}
            <button
                onClick={toggleChat}
                className="fixed bottom-8 right-8 z-50 w-16 h-16 rounded-full bg-gradient-to-r from-turquoise to-deep-blue text-white shadow-2xl flex items-center justify-center hover:scale-110 transition-transform duration-300 animate-pulse-slow group"
            >
                {isOpen ? (
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                ) : (
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                    </svg>
                )}

                {/* Sparkle Icon Overlay */}
                <div className="absolute -top-1 -right-1 w-5 h-5 bg-yellow-400 rounded-full flex items-center justify-center animate-bounce">
                    <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                </div>
            </button>

            {/* Chat Modal */}
            {isOpen && (
                <div className="fixed bottom-28 right-8 z-50 w-96 h-[500px] glass-strong rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-fade-in-up border border-white/40">
                    {/* Header */}
                    <div className="bg-gradient-to-r from-turquoise to-deep-blue p-4 flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm">
                            <span className="text-xl">🤖</span>
                        </div>
                        <div>
                            <h3 className="text-white font-bold">Fethiye Asistanı</h3>
                            <p className="text-white/80 text-xs flex items-center gap-1">
                                <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
                                Çevrimiçi
                            </p>
                        </div>
                    </div>

                    {/* Messages Area */}
                    <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-white/50">
                        {messages.map((msg, idx) => (
                            <div
                                key={idx}
                                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                            >
                                <div
                                    className={`max-w-[80%] p-3 rounded-2xl text-sm ${msg.role === 'user'
                                        ? 'bg-deep-blue text-white rounded-br-none'
                                        : 'bg-white text-gray-800 rounded-bl-none shadow-sm'
                                        }`}
                                >
                                    {msg.content}
                                </div>
                            </div>
                        ))}

                        {/* Typing Indicator */}
                        {isTyping && (
                            <div className="flex justify-start">
                                <div className="bg-white p-3 rounded-2xl rounded-bl-none shadow-sm flex gap-1 items-center">
                                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></span>
                                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100"></span>
                                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200"></span>
                                </div>
                            </div>
                        )}
                        <div ref={messagesEndRef} />
                    </div>

                    {/* Input Area */}
                    <div className="p-4 bg-white border-t border-gray-100">
                        <form onSubmit={(e) => handleSendMessage(e)} className="flex gap-2">
                            <input
                                type="text"
                                value={inputValue}
                                onChange={(e) => setInputValue(e.target.value)}
                                placeholder="Bana bir soru sor..."
                                className="flex-1 bg-gray-100 rounded-full px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-turquoise/50 transition-all"
                            />
                            <button
                                type="submit"
                                className="w-10 h-10 rounded-full bg-turquoise text-white flex items-center justify-center hover:bg-turquoise-dark transition-colors shadow-md"
                            >
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                                </svg>
                            </button>
                        </form>
                    </div>
                </div>
            )}
        </>
    );
}
