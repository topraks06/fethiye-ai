'use client';

export default function WeatherWidget() {
    return (
        <div className="glass px-4 py-2 rounded-full flex items-center gap-3 text-white animate-fade-in-up animate-delay-100">
            <div className="relative w-8 h-8">
                {/* Animated Sun Icon (CSS only) */}
                <div className="absolute inset-0 bg-yellow-400 rounded-full animate-pulse shadow-[0_0_15px_rgba(250,204,21,0.6)]"></div>
            </div>
            <div className="flex flex-col leading-none">
                <span className="text-lg font-bold">28°C</span>
                <span className="text-xs opacity-90 font-medium">Fethiye, Güneşli</span>
            </div>
        </div>
    );
}
