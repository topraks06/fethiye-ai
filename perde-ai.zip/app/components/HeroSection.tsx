'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { useChat } from '@/app/context/ChatContext';
import WeatherWidget from './WeatherWidget';

export default function HeroSection() {
    const [searchQuery, setSearchQuery] = useState('');
    const [isFocused, setIsFocused] = useState(false);
    const { openChatWithQuery } = useChat();
    const [typingText, setTypingText] = useState('');
    const [isDeleting, setIsDeleting] = useState(false);
    const [loopNum, setLoopNum] = useState(0);
    const [typingSpeed, setTypingSpeed] = useState(150);

    const phrases = ["Tatil Planlayın", "Macera Arayın", "Huzuru Bulun", "Lezzetleri Keşfedin"];

    useEffect(() => {
        const handleTyping = () => {
            const i = loopNum % phrases.length;
            const fullText = phrases[i];

            setTypingText(isDeleting ? fullText.substring(0, typingText.length - 1) : fullText.substring(0, typingText.length + 1));

            setTypingSpeed(isDeleting ? 50 : 150);

            if (!isDeleting && typingText === fullText) {
                setTimeout(() => setIsDeleting(true), 2000);
            } else if (isDeleting && typingText === '') {
                setIsDeleting(false);
                setLoopNum(loopNum + 1);
            }
        };

        const timer = setTimeout(handleTyping, typingSpeed);
        return () => clearTimeout(timer);
    }, [typingText, isDeleting, loopNum, typingSpeed, phrases]);

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        if (searchQuery.trim()) {
            openChatWithQuery(searchQuery);
            setSearchQuery('');
        }
    };

    const handleSuggestionClick = (suggestion: string) => {
        openChatWithQuery(suggestion.split(' ')[0]);
    };

    return (
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
            {/* Background Image with Ken Burns Effect */}
            <div className="absolute inset-0 z-0 select-none overflow-hidden">
                <Image
                    src="/oludeniz-hero.jpg"
                    alt="Ölüdeniz Beach - Fethiye"
                    fill
                    priority
                    className="object-cover animate-ken-burns"
                    quality={100}
                />
                {/* Gradient Overlay for Depth */}
                <div className="absolute inset-0 bg-gradient-to-b from-deep-blue/40 via-transparent to-deep-blue/70 mix-blend-multiply"></div>
                <div className="absolute inset-0 bg-black/20"></div>
            </div>

            {/* Weather Widget (Top Right) */}
            <div className="absolute top-24 right-6 z-20 md:top-28 md:right-10">
                <WeatherWidget />
            </div>

            {/* Hero Content */}
            <div className="relative z-10 max-w-5xl mx-auto px-6 lg:px-8 text-center pt-20">
                {/* Main Heading */}
                <h1 className="text-5xl md:text-7xl lg:text-8xl font-black text-white mb-8 animate-fade-in-up tracking-tight drop-shadow-lg">
                    Fethiye'yi Keşfedin
                    <br />
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-turquoise via-turquoise-light to-turquoise animate-pulse">
                        Yapay Zeka ile
                    </span>
                </h1>

                {/* Subheading with Typing Effect */}
                <div className="h-12 md:h-16 mb-12 flex items-center justify-center">
                    <p className="text-xl md:text-3xl text-white/95 font-medium max-w-3xl mx-auto animate-fade-in-up animate-delay-100 leading-relaxed drop-shadow-md">
                        <span className="text-turquoise font-bold">{typingText}</span>
                        <span className="animate-blink border-r-2 border-white ml-1 h-8 inline-block align-middle"></span>
                    </p>
                </div>

                {/* Search Container with Advanced Glassmorphism */}
                <div
                    className={`glass-strong rounded-[2rem] p-4 max-w-3xl mx-auto animate-fade-in-up animate-delay-200 transition-all duration-500 ${isFocused ? 'ring-4 ring-turquoise/30 transform scale-[1.02]' : ''
                        }`}
                >
                    <form onSubmit={handleSearch} className="flex items-center gap-4">
                        {/* Search Icon */}
                        <div className={`pl-4 transition-colors duration-300 ${isFocused ? 'text-turquoise' : 'text-deep-blue/60'}`}>
                            <svg
                                className="w-8 h-8"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={2.5}
                                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                                />
                            </svg>
                        </div>

                        {/* Search Input */}
                        <input
                            type="text"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            onFocus={() => setIsFocused(true)}
                            onBlur={() => setIsFocused(false)}
                            placeholder="Yapay Zekaya Sor: Fethiye&apos;de bugün ne yapalım?"
                            className="flex-1 bg-transparent text-deep-blue placeholder-deep-blue/50 text-xl font-semibold outline-none py-4"
                        />

                        {/* Search Button */}
                        <button
                            type="submit"
                            className="btn-primary px-10 py-5 text-lg font-bold whitespace-nowrap shadow-lg hover:shadow-turquoise/50 active:scale-95 transition-all duration-300"
                        >
                            Keşfet
                        </button>
                    </form>
                </div>

                {/* Quick Suggestions */}
                <div className="mt-10 flex flex-wrap justify-center gap-4 animate-fade-in-up animate-delay-300">
                    {['En iyi plajlar 🏖️', 'Gece hayatı 🌙', 'Tekne turları 🛥️', 'Yerel lezzetler 🍽️'].map((suggestion, index) => (
                        <button
                            key={suggestion}
                            onClick={() => handleSuggestionClick(suggestion)}
                            className="glass px-6 py-3 rounded-full text-white font-semibold hover:bg-white/20 hover:scale-105 hover:border-turquoise/50 transition-all duration-300 backdrop-blur-md shadow-lg"
                            style={{ animationDelay: `${400 + index * 100}ms` }}
                        >
                            {suggestion}
                        </button>
                    ))}
                </div>
            </div>

            {/* Scroll Indicator */}
            <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 z-10 animate-bounce cursor-pointer opacity-80 hover:opacity-100 transition-opacity">
                <div className="w-[30px] h-[50px] rounded-full border-2 border-white flex justify-center p-2 box-content">
                    <div className="w-1 h-3 bg-white rounded-full animate-scroll"></div>
                </div>
            </div>
        </section>
    );
}
