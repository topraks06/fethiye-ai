'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

export default function Sidebar() {
    const pathname = usePathname();

    const menuItems = [
        { name: 'Dashboard', href: '/admin', icon: '📊' },
        { name: 'Turlar', href: '/admin/tours', icon: '🛥️' },
        { name: 'Oteller', href: '/admin/hotels', icon: '🏨' },
        { name: 'Emlak', href: '/admin/real-estate', icon: '🏠' },
        { name: 'Medya', href: '/admin/media', icon: '🖼️' },
        { name: 'Transfer', href: '/admin/transfers', icon: '🚗' },
        { name: 'Kullanıcılar', href: '/admin/users', icon: '👥' },
        { name: 'Ayarlar', href: '/admin/settings', icon: '⚙️' },
    ];

    return (
        <div className="w-64 bg-deep-blue text-white min-h-screen flex flex-col fixed left-0 top-0 h-full z-50 shadow-2xl">
            <div className="p-6 border-b border-white/10">
                <Link href="/" className="text-2xl font-black tracking-tight">
                    <span className="text-turquoise">Fethiye</span>
                    <span className="text-white">.ai</span>
                    <span className="text-xs block font-light text-white/50 mt-1">Admin Panel</span>
                </Link>
            </div>

            <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
                {menuItems.map((item) => {
                    const isActive = pathname === item.href;
                    return (
                        <Link
                            key={item.href}
                            href={item.href}
                            className={`flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-300 group ${isActive
                                ? 'bg-turquoise text-deep-blue font-bold shadow-lg shadow-turquoise/20'
                                : 'hover:bg-white/10 text-white/80 hover:text-white'
                                }`}
                        >
                            <span className="text-xl group-hover:scale-110 transition-transform duration-300">{item.icon}</span>
                            <span>{item.name}</span>
                            {isActive && (
                                <span className="ml-auto w-2 h-2 bg-deep-blue rounded-full animate-pulse"></span>
                            )}
                        </Link>
                    );
                })}
            </nav>

            <div className="p-4 border-t border-white/10">
                <div className="bg-white/5 rounded-xl p-4 flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-turquoise to-blue-500 flex items-center justify-center font-bold text-white">
                        A
                    </div>
                    <div>
                        <p className="text-sm font-bold">Admin User</p>
                        <p className="text-xs text-white/50">Süper Yönetici</p>
                    </div>
                </div>
            </div>
        </div>
    );
}
