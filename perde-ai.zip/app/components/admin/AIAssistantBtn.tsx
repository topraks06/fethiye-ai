'use client';

import { useState } from 'react';

interface AIAssistantBtnProps {
    onGenerate: () => Promise<string>;
    onSuccess: (content: string) => void;
    label?: string;
    loadingLabel?: string;
    icon?: string;
}

export default function AIAssistantBtn({
    onGenerate,
    onSuccess,
    label = "Yapay Zeka ile Oluştur",
    loadingLabel = "Ajan Çalışıyor...",
    icon = "✨"
}: AIAssistantBtnProps) {
    const [loading, setLoading] = useState(false);

    const handleClick = async () => {
        setLoading(true);
        try {
            // Simulate AI delay for realistic feel
            await new Promise(resolve => setTimeout(resolve, 1500));
            const content = await onGenerate();
            onSuccess(content);
        } catch (error) {
            console.error("AI Generation failed", error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <button
            onClick={handleClick}
            disabled={loading}
            className={`
                relative overflow-hidden group px-4 py-2 rounded-lg font-medium text-sm transition-all duration-300
                ${loading
                    ? 'bg-gray-100 text-gray-500 cursor-wait'
                    : 'bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:shadow-lg hover:shadow-purple-500/30 hover:scale-105'
                }
            `}
        >
            <div className="relative z-10 flex items-center gap-2">
                {loading ? (
                    <>
                        <svg className="animate-spin h-4 w-4 text-current" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <span>{loadingLabel}</span>
                    </>
                ) : (
                    <>
                        <span>{icon}</span>
                        <span>{label}</span>
                    </>
                )}
            </div>

            {/* Shimmer Effect */}
            {!loading && (
                <div className="absolute top-0 -inset-full h-full w-1/2 z-5 block transform -skew-x-12 bg-gradient-to-r from-transparent to-white opacity-20 group-hover:animate-shine" />
            )}
        </button>
    );
}
