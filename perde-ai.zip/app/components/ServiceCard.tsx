import Image from 'next/image';

interface ServiceCardProps {
    title: string;
    subtitle?: string;
    price: string;
    image: string;
    badges?: string[];
    onAction?: () => void;
    actionLabel?: string;
}

export default function ServiceCard({
    title,
    subtitle,
    price,
    image,
    badges = [],
    onAction,
    actionLabel = 'İncele'
}: ServiceCardProps) {
    return (
        <div className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-gray-100 h-full flex flex-col">
            <div className="relative h-64 w-full overflow-hidden">
                <Image
                    src={image}
                    alt={title}
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-60 group-hover:opacity-40 transition-opacity duration-300" />

                {/* Badges */}
                <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                    {badges.map((badge, index) => (
                        <span key={index} className="bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-deep-blue shadow-sm">
                            {badge}
                        </span>
                    ))}
                </div>

                {/* Price Tag */}
                <div className="absolute bottom-4 right-4 bg-turquoise text-deep-blue px-4 py-2 rounded-xl font-bold shadow-lg transform translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                    {price}
                </div>
            </div>

            <div className="p-6 flex flex-col flex-1">
                <h3 className="text-xl font-bold text-deep-blue mb-2 group-hover:text-turquoise transition-colors">{title}</h3>
                {subtitle && <p className="text-gray-500 text-sm mb-4 line-clamp-2">{subtitle}</p>}

                <div className="mt-auto pt-4 border-t border-gray-100 flex items-center justify-between">
                    <span className="text-lg font-bold text-deep-blue">{price}</span>
                    <button
                        onClick={onAction}
                        className="text-sm font-bold text-turquoise hover:text-deep-blue transition-colors flex items-center gap-1"
                    >
                        {actionLabel}
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    );
}
