'use client';

import { useState, useEffect } from 'react';
import { useChat } from '@/app/context/ChatContext';
import Link from 'next/link';

export default function Navbar() {
    const [scrolled, setScrolled] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const { toggleChat } = useChat();

    useEffect(() => {
        const handleScroll = () => {
            setScrolled(window.scrollY > 20);
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const navLinks = [
        { name: 'Ana Sayfa', href: '/' },
        { name: 'Keşfet', href: '/tours' },
        { name: 'Oteller', href: '/hotels' },
    ];

    return (
        <>
            <nav
                className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled || isMobileMenuOpen ? 'glass-strong py-3' : 'glass py-5'
                    }`}
            >
                <div className="max-w-7xl mx-auto px-6 lg:px-8">
                    <div className="flex items-center justify-between">
                        {/* Logo */}
                        <div className="flex items-center group cursor-pointer z-50">
                            <Link href="/" className="text-2xl lg:text-3xl font-black tracking-tight transition-transform duration-300 group-hover:scale-105">
                                <span className="text-turquoise drop-shadow-sm">Fethiye</span>
                                <span className="text-deep-blue">.ai</span>
                            </Link>
                        </div>

                        {/* Desktop Navigation */}
                        <div className="hidden md:flex items-center space-x-8">
                            {navLinks.map((link) => (
                                <Link
                                    key={link.name}
                                    href={link.href}
                                    className={`font-medium text-base transition-all duration-300 relative group ${scrolled ? 'text-deep-blue hover:text-turquoise' : 'text-white hover:text-turquoise'
                                        }`}
                                >
                                    {link.name}
                                    <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-turquoise group-hover:w-full transition-all duration-300 ease-out"></span>
                                </Link>
                            ))}

                            {/* Assistant Button */}
                            <button
                                onClick={toggleChat}
                                className={`font-medium text-base transition-all duration-300 relative group flex items-center gap-2 ${scrolled ? 'text-deep-blue hover:text-turquoise' : 'text-white hover:text-turquoise'
                                    }`}
                            >
                                <span>Asistan</span>
                                <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
                            </button>
                        </div>

                        {/* Mobile Menu Button */}
                        <button
                            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                            className={`md:hidden p-2 rounded-lg transition-colors z-50 ${scrolled || isMobileMenuOpen ? 'text-deep-blue hover:bg-gray-100' : 'text-white hover:bg-white/10'
                                }`}
                        >
                            {isMobileMenuOpen ? (
                                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            ) : (
                                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 6h16M4 12h16M4 18h16" />
                                </svg>
                            )}
                        </button>
                    </div>
                </div>
            </nav>

            {/* Mobile Menu Overlay */}
            <div
                className={`fixed inset-0 z-40 bg-white/95 backdrop-blur-xl transition-transform duration-500 ease-in-out md:hidden ${isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
                    }`}
            >
                <div className="flex flex-col items-center justify-center h-full space-y-8">
                    {navLinks.map((link) => (
                        <Link
                            key={link.name}
                            href={link.href}
                            onClick={() => setIsMobileMenuOpen(false)}
                            className="text-2xl font-bold text-deep-blue hover:text-turquoise transition-colors"
                        >
                            {link.name}
                        </Link>
                    ))}
                    <button
                        onClick={() => {
                            setIsMobileMenuOpen(false);
                            toggleChat();
                        }}
                        className="text-2xl font-bold text-deep-blue hover:text-turquoise transition-colors flex items-center gap-2"
                    >
                        Asistan
                        <span className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></span>
                    </button>
                </div>
            </div>
        </>
    );
}
