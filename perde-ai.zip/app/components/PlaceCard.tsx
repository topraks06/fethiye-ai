import Image from 'next/image';
import { Place } from '@/lib/data';

export default function PlaceCard({ place }: { place: Place }) {
    return (
        <div className="group relative h-96 w-full overflow-hidden rounded-2xl cursor-pointer">
            <Image
                src={place.image}
                alt={place.title}
                fill
                className="object-cover transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-90 transition-opacity duration-300 group-hover:opacity-100" />

            <div className="absolute bottom-0 left-0 p-6 text-white transform transition-transform duration-300 group-hover:translate-y-[-10px]">
                <h3 className="text-2xl font-bold mb-2">{place.title}</h3>
                <p className="text-sm text-gray-200 line-clamp-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100">
                    {place.description}
                </p>
            </div>
        </div>
    );
}
