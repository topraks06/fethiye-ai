'use client';

import { useState } from 'react';
import AIAssistantBtn from '../../components/admin/AIAssistantBtn';

export default function ToursAdminPage() {
    const [tours, setTours] = useState([
        { id: 1, title: '12 Adalar Tekne Turu', price: '₺750', status: 'Aktif' },
        { id: 2, title: 'Ölüdeniz Yamaç Paraşütü', price: '₺3500', status: 'Aktif' },
        { id: 3, title: 'Saklıkent Safari', price: '₺600', status: 'Pasif' },
    ]);

    const [isEditing, setIsEditing] = useState(false);
    const [currentTour, setCurrentTour] = useState({ title: '', description: '', price: '' });

    const handleAIGenerate = async () => {
        // Mock AI generation based on title
        const title = currentTour.title || "Fethiye Tekne Turu";
        return `✨ **${title}** ile unutulmaz bir gün geçirin! 
        
Fethiye'nin kristal berraklığındaki sularında, lüks teknemizle maviliklere yelken açıyoruz. 
        
**Tur Özellikleri:**
✅ Öğle yemeği dahil (Akdeniz mutfağı)
✅ 5 farklı koy ziyareti
✅ Profesyonel rehberlik
✅ Sınırsız meşrubat

Bu eşsiz deneyimi kaçırmayın, hemen yerinizi ayırtın!`;
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-800">Tur Yönetimi</h2>
                <button
                    onClick={() => setIsEditing(true)}
                    className="bg-deep-blue text-white px-4 py-2 rounded-lg hover:bg-turquoise hover:text-deep-blue transition-colors font-bold"
                >
                    + Yeni Tur Ekle
                </button>
            </div>

            {/* Tour List */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-gray-50 border-b border-gray-100">
                        <tr>
                            <th className="p-4 font-bold text-gray-600">Tur Adı</th>
                            <th className="p-4 font-bold text-gray-600">Fiyat</th>
                            <th className="p-4 font-bold text-gray-600">Durum</th>
                            <th className="p-4 font-bold text-gray-600">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        {tours.map((tour) => (
                            <tr key={tour.id} className="border-b border-gray-50 hover:bg-gray-50">
                                <td className="p-4 font-medium text-gray-800">{tour.title}</td>
                                <td className="p-4 text-gray-600">{tour.price}</td>
                                <td className="p-4">
                                    <span className={`px-2 py-1 rounded-full text-xs font-bold ${tour.status === 'Aktif' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                                        }`}>
                                        {tour.status}
                                    </span>
                                </td>
                                <td className="p-4">
                                    <button className="text-blue-500 hover:text-blue-700 mr-3">Düzenle</button>
                                    <button className="text-red-500 hover:text-red-700">Sil</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Edit/Create Modal (Simplified) */}
            {isEditing && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
                    <div className="bg-white rounded-2xl p-8 w-full max-w-2xl shadow-2xl relative">
                        <button
                            onClick={() => setIsEditing(false)}
                            className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
                        >
                            ✕
                        </button>

                        <div className="flex items-center gap-3 mb-6">
                            <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center text-xl">
                                🤖
                            </div>
                            <div>
                                <h3 className="text-xl font-bold text-gray-800">Yeni Tur Oluştur</h3>
                                <p className="text-sm text-gray-500">Yapay zeka asistanı içerik oluşturmanıza yardım etsin.</p>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-bold text-gray-700 mb-1">Tur Başlığı</label>
                                <input
                                    type="text"
                                    className="w-full border border-gray-200 rounded-lg p-3 focus:outline-none focus:border-turquoise"
                                    placeholder="Örn: Gün Batımı Tekne Turu"
                                    value={currentTour.title}
                                    onChange={(e) => setCurrentTour({ ...currentTour, title: e.target.value })}
                                />
                            </div>

                            <div>
                                <div className="flex justify-between items-center mb-1">
                                    <label className="block text-sm font-bold text-gray-700">Açıklama</label>
                                    <AIAssistantBtn
                                        label="AI ile Açıklama Yaz"
                                        loadingLabel="Ajan Yazıyor..."
                                        onGenerate={handleAIGenerate}
                                        onSuccess={(content) => setCurrentTour({ ...currentTour, description: content })}
                                    />
                                </div>
                                <textarea
                                    className="w-full border border-gray-200 rounded-lg p-3 h-40 focus:outline-none focus:border-turquoise font-light"
                                    placeholder="Tur detayları buraya gelecek..."
                                    value={currentTour.description}
                                    onChange={(e) => setCurrentTour({ ...currentTour, description: e.target.value })}
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 mb-1">Fiyat</label>
                                    <input
                                        type="text"
                                        className="w-full border border-gray-200 rounded-lg p-3 focus:outline-none focus:border-turquoise"
                                        placeholder="₺"
                                        value={currentTour.price}
                                        onChange={(e) => setCurrentTour({ ...currentTour, price: e.target.value })}
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 mb-1">Durum</label>
                                    <select className="w-full border border-gray-200 rounded-lg p-3 focus:outline-none focus:border-turquoise">
                                        <option>Aktif</option>
                                        <option>Pasif</option>
                                    </select>
                                </div>
                            </div>

                            <div className="flex justify-end gap-3 mt-6">
                                <button
                                    onClick={() => setIsEditing(false)}
                                    className="px-6 py-3 rounded-lg text-gray-600 hover:bg-gray-100 font-bold"
                                >
                                    İptal
                                </button>
                                <button className="px-6 py-3 rounded-lg bg-deep-blue text-white hover:bg-turquoise hover:text-deep-blue transition-colors font-bold shadow-lg">
                                    Kaydet
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
