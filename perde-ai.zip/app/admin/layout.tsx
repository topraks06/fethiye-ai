import Sidebar from '../components/admin/Sidebar';

export default function AdminLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <div className="min-h-screen bg-gray-50 flex font-sans">
            <Sidebar />
            <div className="flex-1 ml-64">
                {/* Top Header */}
                <header className="bg-white shadow-sm h-16 flex items-center justify-between px-8 sticky top-0 z-40">
                    <h1 className="text-xl font-bold text-gray-800">Yönetim Paneli</h1>
                    <div className="flex items-center space-x-4">
                        <button className="p-2 text-gray-400 hover:text-deep-blue transition-colors relative">
                            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
                            🔔
                        </button>
                        <div className="h-8 w-px bg-gray-200"></div>
                        <span className="text-sm text-gray-500">v1.0.0</span>
                    </div>
                </header>

                {/* Main Content */}
                <main className="p-8">
                    {children}
                </main>
            </div>
        </div>
    );
}
