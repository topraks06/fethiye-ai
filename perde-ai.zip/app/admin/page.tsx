'use client';

import { useState, useEffect } from 'react';

export default function AdminDashboard() {
    const [stats, setStats] = useState([
        { title: 'Toplam Rezervasyon', value: '1,248', change: '+12%', icon: '📅', color: 'bg-blue-500' },
        { title: 'Aylık Gelir', value: '₺845,000', change: '+8%', icon: '💰', color: 'bg-green-500' },
        { title: 'Aktif Kullanıcı', value: '3,402', change: '+24%', icon: '👥', color: 'bg-purple-500' },
        { title: 'Ortalama Puan', value: '4.9', change: '+0.1', icon: '⭐', color: 'bg-yellow-500' },
    ]);

    const [aiInsights, setAiInsights] = useState<string[]>([]);
    const [loadingInsights, setLoadingInsights] = useState(true);

    useEffect(() => {
        // Simulate AI analyzing data
        const timer = setTimeout(() => {
            setAiInsights([
                "🚀 **Tekne Turları** bu hafta %20 artış gösterdi. Yeni bir 'Gün Batımı Turu' paketi oluşturmanızı öneririm.",
                "⚠️ **Otel Rezervasyonları** hafta sonu için doluluk oranına yaklaşıyor (%85). Fiyatları %10 artırabiliriz.",
                "💡 **Kullanıcı Yorumları:** 'Kahvaltı' kelimesi olumlu yorumlarda sıkça geçiyor. Bunu pazarlamada kullanın."
            ]);
            setLoadingInsights(false);
        }, 2000);

        return () => clearTimeout(timer);
    }, []);

    return (
        <div className="space-y-8">
            {/* Welcome Section */}
            <div className="bg-gradient-to-r from-deep-blue to-turquoise rounded-2xl p-8 text-white shadow-xl relative overflow-hidden">
                <div className="relative z-10">
                    <h2 className="text-3xl font-bold mb-2">Hoş Geldin, Admin! 👋</h2>
                    <p className="text-white/80 text-lg">
                        Bugün Fethiye.ai platformunda işler yolunda gidiyor. Yapay zeka ajanların senin için çalışıyor.
                    </p>
                </div>
                <div className="absolute right-0 bottom-0 opacity-10 transform translate-x-10 translate-y-10">
                    <svg className="w-64 h-64" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z" />
                    </svg>
                </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {stats.map((stat, index) => (
                    <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                        <div className="flex items-center justify-between mb-4">
                            <div className={`w-12 h-12 rounded-lg ${stat.color} bg-opacity-10 flex items-center justify-center text-2xl`}>
                                {stat.icon}
                            </div>
                            <span className="text-green-500 font-bold text-sm bg-green-50 px-2 py-1 rounded-full">
                                {stat.change}
                            </span>
                        </div>
                        <h3 className="text-gray-500 text-sm font-medium">{stat.title}</h3>
                        <p className="text-2xl font-black text-gray-800 mt-1">{stat.value}</p>
                    </div>
                ))}
            </div>

            {/* AI Insights Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* AI Manager Insights */}
                <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                    <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                                🤖
                            </div>
                            <div>
                                <h3 className="text-lg font-bold text-gray-800">Baş Yönetici Ajan</h3>
                                <p className="text-sm text-gray-500">Günlük Analiz Raporu</p>
                            </div>
                        </div>
                        <span className="text-xs text-gray-400">Az önce güncellendi</span>
                    </div>

                    <div className="space-y-4">
                        {loadingInsights ? (
                            <div className="space-y-3 animate-pulse">
                                <div className="h-4 bg-gray-100 rounded w-3/4"></div>
                                <div className="h-4 bg-gray-100 rounded w-1/2"></div>
                                <div className="h-4 bg-gray-100 rounded w-5/6"></div>
                            </div>
                        ) : (
                            aiInsights.map((insight, idx) => (
                                <div key={idx} className="flex gap-4 p-4 bg-gray-50 rounded-lg border border-gray-100 hover:bg-purple-50 transition-colors">
                                    <div className="mt-1">✨</div>
                                    <p className="text-gray-700 leading-relaxed" dangerouslySetInnerHTML={{ __html: insight.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
                                </div>
                            ))
                        )}
                    </div>
                </div>

                {/* Recent Activity */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                    <h3 className="text-lg font-bold text-gray-800 mb-6">Son Aktiviteler</h3>
                    <div className="space-y-6">
                        {[
                            { user: 'Ahmet Y.', action: '12 Adalar Turu rezervasyonu yaptı', time: '5 dk önce' },
                            { user: 'Ayşe K.', action: 'Villa Likya için fiyat teklifi istedi', time: '12 dk önce' },
                            { user: 'Mehmet T.', action: 'Havalimanı transferi satın aldı', time: '34 dk önce' },
                            { user: 'Zeynep B.', action: 'Yapay zeka asistanı ile görüştü', time: '1 saat önce' },
                        ].map((item, idx) => (
                            <div key={idx} className="flex items-start gap-3">
                                <div className="w-2 h-2 mt-2 rounded-full bg-turquoise"></div>
                                <div>
                                    <p className="text-sm text-gray-800 font-medium">{item.user}</p>
                                    <p className="text-xs text-gray-500">{item.action}</p>
                                    <p className="text-[10px] text-gray-400 mt-1">{item.time}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}
