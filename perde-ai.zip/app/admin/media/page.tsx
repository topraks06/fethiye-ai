'use client';

import { useState } from 'react';

export default function MediaAdminPage() {
    const [isUploading, setIsUploading] = useState(false);

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-800">Medya Kütüphanesi</h2>
                <button
                    className="bg-deep-blue text-white px-4 py-2 rounded-lg hover:bg-turquoise hover:text-deep-blue transition-colors font-bold flex items-center gap-2"
                >
                    <span>📤</span> Medya Yükle
                </button>
            </div>

            {/* Upload Area */}
            <div className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center hover:border-turquoise hover:bg-turquoise/5 transition-colors cursor-pointer">
                <div className="text-4xl mb-4">☁️</div>
                <h3 className="text-lg font-bold text-gray-700">Dosyaları buraya sürükleyin</h3>
                <p className="text-gray-500 mt-2">veya seçmek için tıklayın</p>
                <p className="text-xs text-gray-400 mt-4">JPG, PNG, MP4 (Max 50MB)</p>
            </div>

            {/* Media Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {[1, 2, 3, 4, 5, 6, 7, 8].map((item) => (
                    <div key={item} className="group relative aspect-square bg-gray-100 rounded-lg overflow-hidden border border-gray-200">
                        <img
                            src={`https://images.unsplash.com/photo-1533105079780-92b9be482077?q=80&w=300&auto=format&fit=crop&random=${item}`}
                            alt="Media"
                            className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                            <button className="p-2 bg-white rounded-full text-red-500 hover:bg-red-50">🗑️</button>
                            <button className="p-2 bg-white rounded-full text-blue-500 hover:bg-blue-50">👁️</button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
