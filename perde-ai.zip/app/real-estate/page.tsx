'use client';

import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import ChatWidget from '../components/ChatWidget';
import ServiceCard from '../components/ServiceCard';
import { realEstate } from '@/lib/data';
import { useChat } from '@/app/context/ChatContext';

export default function RealEstatePage() {
    const { openChatWithQuery } = useChat();

    return (
        <div className="min-h-screen bg-off-white">
            <Navbar />

            {/* Hero Section */}
            <div className="relative h-[50vh] flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 z-0">
                    <div className="absolute inset-0 bg-gradient-to-b from-black/70 to-transparent z-10" />
                    <img
                        src="/hotel-thumbnail.jpg"
                        alt="Luxury Villas"
                        className="w-full h-full object-cover animate-ken-burns"
                    />
                </div>
                <div className="relative z-20 text-center text-white px-4">
                    <h1 className="text-5xl md:text-7xl font-black mb-4 drop-shadow-lg">
                        Hayalinizdeki <span className="text-turquoise">Yaşam</span>
                    </h1>
                    <p className="text-xl md:text-2xl max-w-2xl mx-auto font-light">
                        Fethiye'nin en seçkin villaları ve yatırım fırsatları.
                    </p>
                </div>
            </div>

            {/* Content */}
            <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {realEstate.map((item) => (
                        <ServiceCard
                            key={item.id}
                            title={item.title}
                            subtitle={item.location}
                            price={item.price}
                            image={item.image}
                            badges={[item.type, ...item.features]}
                            actionLabel="Detaylı Bilgi"
                            onAction={() => openChatWithQuery(`${item.title} hakkında detaylı bilgi almak istiyorum.`)}
                        />
                    ))}
                </div>
            </div>

            <Footer />
            <ChatWidget />
        </div>
    );
}
