'use client';

import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import ChatWidget from '../components/ChatWidget';
import ServiceCard from '../components/ServiceCard';
import { hotels } from '@/lib/data';
import { useChat } from '@/app/context/ChatContext';

export default function HotelsPage() {
    const { openChatWithQuery } = useChat();

    return (
        <div className="min-h-screen bg-off-white">
            <Navbar />

            {/* Hero Section */}
            <div className="relative h-[50vh] flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 z-0">
                    <div className="absolute inset-0 bg-gradient-to-b from-black/60 to-transparent z-10" />
                    <img
                        src="/hotel-thumbnail.jpg"
                        alt="Luxury Hotels"
                        className="w-full h-full object-cover animate-ken-burns"
                    />
                </div>
                <div className="relative z-20 text-center text-white px-4">
                    <h1 className="text-5xl md:text-7xl font-black mb-4 drop-shadow-lg">
                        Konforun <span className="text-turquoise">Adresi</span>
                    </h1>
                    <p className="text-xl md:text-2xl max-w-2xl mx-auto font-light">
                        Fethiye'nin en seçkin otellerinde unutulmaz bir konaklama deneyimi.
                    </p>
                </div>
            </div>

            {/* Content */}
            <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {hotels.map((hotel) => (
                        <ServiceCard
                            key={hotel.id}
                            title={hotel.name}
                            subtitle="Lüks Konaklama"
                            price={hotel.price}
                            image={hotel.image}
                            badges={[`★ ${hotel.rating}`, 'Denize Sıfır']}
                            actionLabel="Rezervasyon Yap"
                            onAction={() => openChatWithQuery(`${hotel.name} için rezervasyon yapmak istiyorum.`)}
                        />
                    ))}
                </div>
            </div>

            <Footer />
            <ChatWidget />
        </div>
    );
}
