'use client';

import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import dynamic from 'next/dynamic';

// Dynamically import Map to avoid SSR issues with Leaflet
const Map = dynamic(() => import('../components/Map'), { ssr: false });

const locations = [
    { id: 1, title: 'Ölüdeniz', lat: 36.5493, lng: 29.1247, type: 'Plaj' },
    { id: 2, title: 'Amintas Kaya Mezarları', lat: 36.6200, lng: 29.1100, type: 'Tarihi' },
    { id: 3, title: 'Kelebekler Vadisi', lat: 36.4960, lng: 29.1260, type: 'Doğa' },
    { id: 4, title: 'Fethiye Merkez', lat: 36.6213, lng: 29.1164, type: 'Merkez' },
    { id: 5, title: 'Çalış Plajı', lat: 36.6640, lng: 29.1080, type: 'Plaj' },
];

export default function MapPage() {
    return (
        <div className="min-h-screen bg-off-white flex flex-col">
            <Navbar />

            <div className="flex-1 pt-24 pb-10 px-6 lg:px-8 max-w-7xl mx-auto w-full">
                <div className="mb-8 text-center">
                    <h1 className="text-4xl font-black text-deep-blue mb-4 font-serif">Fethiye Haritası</h1>
                    <p className="text-lg text-gray-600">Gezilecek yerleri ve rotaları interaktif haritada keşfedin.</p>
                </div>

                <div className="h-[600px] w-full bg-white p-4 rounded-2xl shadow-xl border border-gray-100">
                    <Map locations={locations} />
                </div>
            </div>

            <Footer />
        </div>
    );
}
