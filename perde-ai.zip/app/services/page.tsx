'use client';

import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import ChatWidget from '../components/ChatWidget';
import { localExperts } from '@/lib/data';
import { useChat } from '@/app/context/ChatContext';
import Image from 'next/image';

export default function ServicesPage() {
    const { openChatWithQuery } = useChat();

    return (
        <div className="min-h-screen bg-off-white">
            <Navbar />

            {/* Hero Section */}
            <div className="relative h-[40vh] flex items-center justify-center overflow-hidden bg-deep-blue">
                <div className="absolute inset-0 z-0 opacity-20">
                    {/* Abstract pattern or simple bg */}
                    <div className="w-full h-full bg-[url('/window.svg')] bg-repeat opacity-10"></div>
                </div>
                <div className="relative z-20 text-center text-white px-4">
                    <h1 className="text-4xl md:text-6xl font-black mb-4">
                        Yerel <span className="text-turquoise">Uzmanlar</span>
                    </h1>
                    <p className="text-lg md:text-xl max-w-2xl mx-auto font-light opacity-80">
                        Elektrikçiden rehbere, Fethiye'nin güvenilir esnafı ve ustaları burada.
                    </p>
                </div>
            </div>

            {/* Content */}
            <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {localExperts.map((expert) => (
                        <div key={expert.id} className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all border border-gray-100 flex items-center gap-6">
                            <div className="relative w-20 h-20 rounded-full overflow-hidden flex-shrink-0 border-2 border-turquoise/20">
                                <Image
                                    src={expert.image}
                                    alt={expert.name}
                                    fill
                                    className="object-cover"
                                />
                            </div>
                            <div>
                                <h3 className="text-xl font-bold text-deep-blue">{expert.name}</h3>
                                <p className="text-turquoise font-medium">{expert.profession}</p>
                                <div className="flex items-center gap-1 text-yellow-500 text-sm mt-1">
                                    <span>★</span>
                                    <span>{expert.rating}</span>
                                </div>
                                <button
                                    onClick={() => openChatWithQuery(`${expert.name} (${expert.profession}) ile iletişime geçmek istiyorum.`)}
                                    className="mt-3 text-sm font-bold text-gray-400 hover:text-deep-blue transition-colors"
                                >
                                    İletişime Geç →
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            <Footer />
            <ChatWidget />
        </div>
    );
}
