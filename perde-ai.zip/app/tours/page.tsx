'use client';

import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import ChatWidget from '../components/ChatWidget';
import ServiceCard from '../components/ServiceCard';
import { tours } from '@/lib/data';
import { useChat } from '@/app/context/ChatContext';

export default function ToursPage() {
    const { openChatWithQuery } = useChat();

    return (
        <div className="min-h-screen bg-off-white">
            <Navbar />

            {/* Hero Section */}
            <div className="relative h-[50vh] flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 z-0">
                    <div className="absolute inset-0 bg-gradient-to-b from-deep-blue/60 to-deep-blue/20 z-10" />
                    <img
                        src="/oludeniz-hero.jpg"
                        alt="Fethiye Tours"
                        className="w-full h-full object-cover animate-ken-burns"
                    />
                </div>
                <div className="relative z-20 text-center text-white px-4">
                    <h1 className="text-5xl md:text-7xl font-black mb-4 drop-shadow-lg">
                        Keşfedilmemişi <span className="text-turquoise">Keşfedin</span>
                    </h1>
                    <p className="text-xl md:text-2xl max-w-2xl mx-auto font-light">
                        Fethiye'nin en özel koyları, macera dolu aktiviteleri ve unutulmaz anları sizi bekliyor.
                    </p>
                </div>
            </div>

            {/* Content */}
            <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {tours.map((tour) => (
                        <ServiceCard
                            key={tour.id}
                            title={tour.title}
                            subtitle={tour.duration}
                            price={tour.price}
                            image={tour.image}
                            badges={[tour.category]}
                            actionLabel="Rezervasyon Yap"
                            onAction={() => openChatWithQuery(`${tour.title} için rezervasyon yapmak istiyorum.`)}
                        />
                    ))}
                </div>
            </div>

            <Footer />
            <ChatWidget />
        </div>
    );
}
