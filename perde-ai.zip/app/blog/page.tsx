'use client';

import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Link from 'next/link';

const blogPosts = [
    {
        id: 1,
        title: "Fethiye'de Mutlaka Görmeniz Gereken 5 Koy",
        excerpt: "Turkuaz suları ve el değmemiş doğasıyla Fethiye'nin saklı cennetlerini keşfedin.",
        image: "/blog-1.jpg",
        category: "Gezi Rehberi",
        date: "24 Kasım 2025"
    },
    {
        id: 2,
        title: "Ölüdeniz'de Yamaç Paraşütü Deneyimi",
        excerpt: "Babadağ'dan süzülürken hissedeceğiniz özgürlük duygusunu ve manzarayı anlattık.",
        image: "/blog-2.jpg",
        category: "Aktiviteler",
        date: "20 Kasım 2025"
    },
    {
        id: 3,
        title: "Fethiye Mutfağı: Ne Yenir?",
        excerpt: "Ege ve Akdeniz mutfağının en lezzetli örneklerini tadabileceğiniz mekanlar.",
        image: "/blog-3.jpg",
        category: "Yeme İçme",
        date: "15 Kasım 2025"
    }
];

export default function BlogPage() {
    return (
        <div className="min-h-screen bg-off-white">
            <Navbar />

            <div className="pt-32 pb-20 px-6 lg:px-8 max-w-7xl mx-auto">
                <div className="text-center mb-16">
                    <h1 className="text-4xl md:text-6xl font-black text-deep-blue mb-6 font-serif">Fethiye Rehberi</h1>
                    <p className="text-xl text-gray-600 max-w-2xl mx-auto font-light">
                        Tatilinizi planlarken ihtiyacınız olan tüm ipuçları, rotalar ve öneriler burada.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                    {blogPosts.map((post) => (
                        <article key={post.id} className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 cursor-pointer">
                            <div className="relative h-64 overflow-hidden">
                                <div className="absolute inset-0 bg-gray-200 animate-pulse" /> {/* Placeholder */}
                                <img
                                    src={post.image}
                                    alt={post.title}
                                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                                    onError={(e) => {
                                        (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1533105079780-92b9be482077?q=80&w=600&auto=format&fit=crop';
                                    }}
                                />
                                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-deep-blue uppercase tracking-wider">
                                    {post.category}
                                </div>
                            </div>
                            <div className="p-8">
                                <div className="text-sm text-gray-400 mb-3">{post.date}</div>
                                <h2 className="text-2xl font-bold text-deep-blue mb-3 font-serif group-hover:text-turquoise transition-colors">
                                    {post.title}
                                </h2>
                                <p className="text-gray-600 font-light leading-relaxed mb-6">
                                    {post.excerpt}
                                </p>
                                <Link href={`/blog/${post.id}`} className="inline-flex items-center text-deep-blue font-bold hover:text-turquoise transition-colors">
                                    Devamını Oku
                                    <svg className="w-4 h-4 ml-2 transform group-hover:translate-x-2 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                                    </svg>
                                </Link>
                            </div>
                        </article>
                    ))}
                </div>
            </div>

            <Footer />
        </div>
    );
}
